
## Description
This website is a user registration and login system built using Node.js and MongoDB. It allows users to create an account, log in with their credentials, and explore various features and functionalities of the site.

## Installation
1. Clone the repository.
2. Install Node.js and MongoDB if not already installed.
/**
 * Install required dependencies for the registration-login form using Node.js and MongoDB.
 * 
 * Steps:
 * 1. Run `npm install express` to install the Express framework.
 * 2. Run `npm install mongoose` to install the Mongoose library for MongoDB.
 * 3. Run `npm install bcrypt` to install the bcrypt library for password hashing.
 * 4. Run `npm install ejs` to install the EJS templating engine.
 * 5. Run `nodemon src/index.js` to start the application using nodemon.
 */

## Usage
1. Open your web browser and navigate to the site's URL localhost:5000.
2. Register a new account or login with an existing account.

## Technologies Used
- Node.js
- Express.js
- MongoDB
- HBS
- CSS


## License
This project is licensed under the [MIT License](https://opensource.org/licenses/MIT).
